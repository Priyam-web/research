import turtle

# create turtle object
t = turtle.Turtle()

# set turtle speed
t.speed(0)

# loop to draw the pattern
for i in range(18):
    t.circle(100)
    t.right(40)
    t.circle(60)
    t.right(40)
    t.circle(40)
    t.right(40)
    t.circle(20)
    t.right(40)

# hide turtle
t.hideturtle()

# keep window open until user closes it
turtle.done()
